
public class Cursor {

	private double x;
	private double y;
	private static boolean alive;
	private double xVelocity;
	private double yVelocity;

	public double getX(){
		return x;
	}

	public double getY(){
		return y;
	}
	public static boolean isAlive(){
		return alive;
	}

	public double getRadius(){
		return .01;
	}

	public boolean kill(){
		return alive = false;
	}


	public Cursor( double x, double y ){
		this.x = x;
		this.y = y;
		alive = true;
	}

	public void update (double time, double mouseX, double mouseY){
		if(alive){
			if( mouseX > 0 && mouseX < 1 && mouseY > 0 && mouseY < 1 )
			{ 
				if( mouseX > x )
					xVelocity += 0.015;
				else
					xVelocity -= 0.015;

				if( mouseY > y )
					yVelocity += 0.015;
				else
					yVelocity -= 0.015;

				xVelocity = Math.max( xVelocity, -0.3 );
				xVelocity = Math.min( xVelocity, 0.3 );

				yVelocity = Math.max( yVelocity, -0.3 );
				yVelocity = Math.min( yVelocity, 0.3 );
			}			

			x = x + xVelocity*time;
			y = y + yVelocity*time;

			if ( x + getRadius() > 1)
				x = 1 - getRadius();
			if (x - getRadius () < 0)
				x=0+ getRadius(); 
			if (y + getRadius()> 1)
				y = 1 - getRadius();
			if (y - getRadius()< 0)
				y = 0 + getRadius();
		}


	}	
	
	public void Draw() {
		StdDraw.setPenColor(StdDraw.LIGHT_GRAY);
		StdDraw.setPenRadius(0.003);
		StdDraw.line(x-.005, y, x-.005, y+0.015);
		StdDraw.line(x+.005, y, x+.005, y+0.015);
		StdDraw.setPenRadius(0.001);
		StdDraw.setPenColor();
		StdDraw.line(x-.005, y, x-.005, y+0.015);
		StdDraw.line(x+.005, y, x+.005, y+0.015);
		StdDraw.setPenRadius();
		StdDraw.setPenColor(StdDraw.LIGHT_GRAY);
		StdDraw.filledCircle(x, y, getRadius());
		StdDraw.setPenColor(StdDraw.WHITE);
		StdDraw.filledCircle(x+.005, y, getRadius()/3);
		StdDraw.filledCircle(x-.005, y, getRadius()/3);
		StdDraw.setPenColor(StdDraw.BLACK);
		StdDraw.filledCircle(x+.005, y, getRadius()/5);
		StdDraw.filledCircle(x-.005, y, getRadius()/5);
		StdDraw.filledCircle(x, y - 0.002, getRadius()/6);
		StdDraw.line(x-0.004, y-0.0055, x+0.004, y-0.0055);
	}	
	
	static void end() {

		int options = 1;

		switch(options) {

		case 1:
			new TitleScreen();
			break;

		}

	}
	
}
